#pragma once

namespace RudyTheCrawler
{

class IThreadable
{
	public:
		virtual void run() = 0;
};

};